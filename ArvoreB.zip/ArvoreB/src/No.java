public class No {
int valor;
No esquerda;
No direita;

public No( int valor) {
    this.valor = valor;
    this.esquerda = null;
    this.direita = null;
}
}
